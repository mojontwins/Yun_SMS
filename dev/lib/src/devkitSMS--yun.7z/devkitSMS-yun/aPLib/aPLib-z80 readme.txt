Z80 aPLib decompressor
======================

1/12/2008

This is a repackaging and conversion for Sega 8-bit systems of Dan Weiss's
TI-targetting Z80 decompressor for the aPLib compression format. See

http://www.ibsensoftware.com/products_aPLib.html

for the original software and description, and

http://home.comcast.net/~alanweiss3/dwedit/files/apack_demo.zip (dead link)

for Dan's version. I optimised it a bit for size (primarily) and speed, and
adjusted a copy to write to VRAM via the I/O ports on Sega 8-bit systems.

Maxim
