how to build crt0 yourself

for SMS/GG:
```
sdasz80 -g -o crt0_sms.s
```

for SG-1000:
```
sdasz80 -g -o crt0_sg.s
```
