// Mojon Twins own hacks

// My sprite routines need my own initSpritesEx routine.
// Sorry for the incompatibilities by I need every cycle.

#include "SMSlib.h"
#include "SMSlib_common.c"

#if MAXSPRITES==64
extern unsigned char SpriteTableY [MAXSPRITES];
#else
extern unsigned char SpriteTableY [MAXSPRITES + 1];
#endif
extern unsigned char SpriteTableXN [MAXSPRITES * 2];
extern unsigned char SpriteNextFree;

unsigned char xx, yy, xw, x0;
unsigned char *stXN, *stY, *stAux;
unsigned char mtgrdx, mtgrdy;

void SMS_MT_initSpritesEx (unsigned char initial) {
	SpriteNextFree = initial;
	stY = &SpriteTableY [SpriteNextFree]; stXN = &SpriteTableXN [SpriteNextFree * 2];
}

void SMS_MT_finalizeSpritesEx (void) {
	*stY = 0xD0;
}

void SMS_MT_addSpriteFast (unsigned char x, unsigned char y, unsigned char tile) {
	*stY ++ = y;
	*stXN ++ = x;
	*stXN ++ = tile;
}

void SMS_MT_setSpriteFastAt (unsigned char x, unsigned char y, unsigned char sprite, unsigned char tile) {
	SpriteTableY [sprite] = y;
	stAux = &SpriteTableXN [sprite + sprite];
	*stAux++ = x;
	*stAux = tile;
}

void SMS_MT_addMetaspriteSimple (unsigned char x, unsigned char y, unsigned char *metasprite) {
	// Read header: xorg, yorg, w h
	mtgrdx = x + *metasprite ++; mtgrdy = y + *metasprite ++; xw = *metasprite ++; yy = *metasprite ++;

	// Iterate
	x0 = mtgrdx;
	
	while (yy --) {
		mtgrdx = x0; xx = xw; while (xx --) {
			*stY ++ = mtgrdy; *stXN ++ = mtgrdx; *stXN ++ = *metasprite ++;
			SpriteNextFree ++;
			mtgrdx += 8;			
		}
		mtgrdy += 8;
	}
}

void SMS_MT_add2x2MetaSpriteSimpleUnrolled (unsigned char x, unsigned char y, unsigned char *metasprite) {
	// Read header: xorg, yorg, w h
	mtgrdx = x + *metasprite ++; mtgrdy = y + *metasprite ++; x0 = mtgrdx;
	metasprite += 2;	// Skip w, h
	
	*stY ++ = mtgrdy; *stXN ++ = mtgrdx; *stXN ++ = *metasprite ++; mtgrdx += 8;
	*stY ++ = mtgrdy; *stXN ++ = mtgrdx; *stXN ++ = *metasprite ++; mtgrdx = x0; mtgrdy += 8; 
	*stY ++ = mtgrdy; *stXN ++ = mtgrdx; *stXN ++ = *metasprite ++; mtgrdx += 8;
	*stY ++ = mtgrdy; *stXN ++ = mtgrdx; *stXN ++ = *metasprite ++;
	SpriteNextFree += 4;
}

void SMS_MT_add2x3MetaSpriteSimpleUnrolled (unsigned char x, unsigned char y, unsigned char *metasprite) {
	// Read header: xorg, yorg, w h
	mtgrdx = x + *metasprite ++; mtgrdy = y + *metasprite ++; x0 = mtgrdx;
	metasprite += 2;	// Skip w, h
	
	*stY ++ = mtgrdy; *stXN ++ = mtgrdx; *stXN ++ = *metasprite ++; mtgrdx += 8;
	*stY ++ = mtgrdy; *stXN ++ = mtgrdx; *stXN ++ = *metasprite ++; mtgrdx = x0; mtgrdy += 8; 
	*stY ++ = mtgrdy; *stXN ++ = mtgrdx; *stXN ++ = *metasprite ++; mtgrdx += 8;
	*stY ++ = mtgrdy; *stXN ++ = mtgrdx; *stXN ++ = *metasprite ++; mtgrdx = x0; mtgrdy += 8; 
	*stY ++ = mtgrdy; *stXN ++ = mtgrdx; *stXN ++ = *metasprite ++; mtgrdx += 8;
	*stY ++ = mtgrdy; *stXN ++ = mtgrdx; *stXN ++ = *metasprite ++;
	SpriteNextFree += 6;
}

unsigned int adr;
void SMS_MT_draw2x2MetaTileatXY (unsigned char x, unsigned char y, unsigned int *metatile) {
	adr = XYtoADDR (x, y);
	SMS_setAddr (adr);
	SMS_setTile (*metatile ++); SMS_setTile (*metatile ++);
	adr += 64;
	SMS_setAddr (adr);
	SMS_setTile (*metatile ++); SMS_setTile (*metatile);
}

void SMS_MT_draw2x2MetaTileRowatXY (unsigned char x, unsigned char y, unsigned char r, unsigned int *metatile) {
	adr = XYtoADDR (x, y);
	// Advance row
	if (r) metatile += 2;
	SMS_setAddr (adr);
	SMS_setTile (*metatile ++); SMS_setTile (*metatile);
}

void SMS_MT_draw2x2MetaTileColatXY (unsigned char x, unsigned char y, unsigned char c, unsigned int *metatile) {
	adr = XYtoADDR (x, y);
	// Advance column
	if (c) metatile ++;
	SMS_setAddr (adr);
	SMS_setTile (*metatile); metatile += 2;
	adr += 64;
	SMS_setAddr (adr);
	SMS_setTile (*metatile); 
}

#define SETVDPDATAPORT  __asm ld c,#_VDPDataPort __endasm
void OUTI24 (void *src) __z88dk_fastcall;
void UNSAFE_SMS_MT_VRAMmemcpy24 (unsigned int dst, void *src) {
  SMS_set_address_VRAM(dst);
  SETVDPDATAPORT;
  OUTI24(src);
}

#pragma disable_warning 85
void UNSAFE_SMS_MT_ScrollUpdateVDP (void *src, unsigned int column) {
__asm

	; Get parameters from the stack

	pop bc
	pop de			; *src
	pop hl   		; column
	push hl
	push de
	push bc

	; Get address from column, set control bits = 01 (write to VRAM)

	add hl, hl		; column * 2
	ld bc, #0x7800	; Address = (01) (11 1000 0000 0000)
	add hl, bc

	; Draw 24 tiles

	.rept	24

		; hl -> address in VRAM
		; de -> points to next tile in buffer

		push hl

		; write address to control port

		ld a, l
		out (_VDPControlPort), a
		ld a, h
		out (_VDPControlPort), a

		; write new tile

		ex de, hl

		ld c, #_VDPDataPort
		outi 
		outi

		ex de, hl

		; now de points to the next tile in buffer

		pop hl

		; Next row
		ld bc, #0x40
		add hl, bc

	.endm

__endasm;

}
